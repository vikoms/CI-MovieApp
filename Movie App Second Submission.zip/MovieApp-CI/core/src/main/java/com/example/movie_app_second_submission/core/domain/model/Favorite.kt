package com.example.movie_app_second_submission.core.domain.model

data class Favorite(
    val id: Int? = null,
    val backdropPath: String? = null,
    val type: String? = null,
    val title: String? = null,
    val date: String? = null,
)